#include <iostream>
#include "stem_student.h"
using namespace std;

int main(void){
    stem_student yamada("山田一郎",50, 30, 20, 80, 60);
    yamada.print();
}