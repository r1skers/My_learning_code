#include <iostream>
#include "animal_base.h"

animal_base::animal_base(int h)
{
    height = h;
}
