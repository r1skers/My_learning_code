#ifndef RAYTRACE_H
#define RAYTRACE_H
#include <vector>
#include "object_base.h"
#include "camera.h"
class CRayTrace
{
public:
    CRayTrace(COLORREF bgcolor, int tracelevel, double envlight_r,
        double envlight_g, double envlight_b);
    virtual ~CRayTrace();
    CBitmap& Start();
    void AddObject(CObjectBase* obj);
    void SetCamera(vec3d pos, vec3d target, double angle, double turnangle,
        int screen_cx, int screen_cy);
protected:
    std::vector<CObjectBase*> object_list;
    CCamera camera;
    COLORREF bgcolor;
    int tracelevel;
    CBitmap image;
    struct StrengthRGB
    {
        double r;
        double g;
        double b;
        StrengthRGB() { r = 0; g = 0; b = 0; }
        StrengthRGB(double _r, double _g, double _b) { r = _r; g = _g; b = _b; }
    } envlight;
    struct HitInfo
    {
        CObjectBase* object;
        vec3d pos;
        vec3d normal;
        int r, g, b;
        double transparency;
        double reflection;
        double refraction;
        int highlightdiaphragm;
        double highlight;
    };
    struct RayInfo
    {
        vec3d viewpoint;
        vec3d ray;
        int inout;
        int count;
        RayInfo() {}
        RayInfo(vec3d vp, vec3d r, int io, int c)
        {
            viewpoint = vp;
            ray = r;
            inout = io;
            count = c;
        }
    };
    virtual double RayTrace(CRayTrace::RayInfo ray, int* r, int* g, int* b,
        double* transparency);
    double RayCast(CRayTrace::RayInfo ray, CRayTrace::HitInfo* phit);
};
#endif